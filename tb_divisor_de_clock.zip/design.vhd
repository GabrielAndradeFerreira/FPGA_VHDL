-- Code your design here
-- Divisor de clock simples

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity clock_div is --declaro a entidade que vai guadar os sinais de clock dos FFs
    port(
        clk_in  : in  std_logic; --caminho para o clock de entrada
        reset   : in  std_logic; --caminho para o reset
        clk_out : out std_logic	 --caminho para o clock de saída
    );
end entity;

architecture Behavioral of clock_div is --inicia o hardware
    signal count : unsigned(3 downto 0) := (others => '0'); --habilita um registrador interno com sinal "count" com um 
    														--vetor de 4bits (0~3) e atribui '0' ao sinal.
    signal clk_reg : std_logic := '0'; --habilita um registrador interno que vai manipular o clock.
begin

process(clk_in, reset)
begin
    if reset = '1' then				--se o reset == 1 então o contador e o clock regular zeram.
        count   <= (others => '0');
        clk_reg <= '0';

    elsif rising_edge(clk_in) then --se não, incrementa o contador num FF borda de subida
        count <= count + 1;

        --quando chega em 5, alterna saída (NA VERDADE, SÃO 6, POIS AO CHEGAR EM CONFIRMAR QUE O CONTADOR CHEGOU EM 5,
        --O SISTEMA SÓ VAI TRANSITAR PARA O PRÓXIMO ESTADO NA PRÓXIMA BORDA DE SUBIDA, OU SEJA, NA SEXTA ITERAÇÃO.
        
        if count = 5 then --Para alterar meu divisor, basta manipular o estouro do contador nessa lina
            clk_reg <= not clk_reg;
            count <= (others => '0');
        end if;
    end if;
end process;

clk_out <= clk_reg; --joga o valor do sinal de clock regular interno no sinal de clock de saída

end architecture;