Clock Divider in VHDL

This project implements a **clock divider** using **VHDL**, a fundamental building block in digital systems and FPGA design.

The goal is to generate a lower-frequency clock signal from a higher-frequency input clock using sequential logic.


Overview

A clock divider is used to slow down a clock signal by a specific factor. This is essential in digital systems where different components require different operating frequencies.

In this implementation:

* The input clock (clk_in) is divided using a counter
* The output clock (clk_out) toggles after a fixed number of input cycles
* The design demonstrates time-based control using hardware logic

How It Works

The divider uses:

* An internal counter (`count`)
* A register (`clk_reg`) to store the output state

Operation:

1. The counter increments on every rising edge of clk_in
2. When the counter reaches a predefined value:

   * The output clock toggles (0 → 1 or 1 → 0)
   * The counter resets to zero
3. This process repeats continuously

Frequency Division

The output frequency depends on the counter limit.

General rule:

text
f_out ≈ f_in / (2 × (N + 1))


Where:

* N = maximum counter value

Example:

If the counter counts from 0 to 4:

text
f_out = f_in / 10

Simulation

The design was simulated using:

* GHDL
* EDA Playground

The behavior is validated through terminal output using report.

Example Output

text
Tempo: 20 ns | clk_in='1' | clk_out='0'
Tempo: 30 ns | clk_in='1' | clk_out='0'
Tempo: 70 ns | clk_in='1' | clk_out='1'
Tempo: 130 ns | clk_in='1' | clk_out='0'


This demonstrates that clk_out changes state less frequently than clk_in.

Concepts Covered

* Clock-driven sequential logic
* Frequency division
* Counters in hardware
* Signal synchronization
* Testbench-based validation

Notes

* The output clock is not guaranteed to have a perfect 50% duty cycle depending on the counter value
* This implementation is intended for learning purposes

Possible Improvements

* Parameterizable divider (configurable division factor)
* Precise duty cycle control
* Multiple derived clock outputs
* Integration with other modules (e.g., display or communication interfaces)

Purpose

This project is part of a study path focused on:

* FPGA development
* Embedded systems
* Digital design using VHDL

Author

Gabriel A. Ferreira
Software developer in training focused on embedded systems
