-- Code your testbench here
-- Testbench do divisor de clock

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_clock_div is
end entity;

architecture sim of tb_clock_div is
	
    --declaração dos sinais para manipulação do clock
    signal clk_in  : std_logic := '0';
    signal reset   : std_logic := '0';
    signal clk_out : std_logic;

begin

    --instância do circuito divisor
    uut: entity work.clock_div
        port map (
            --liga os sinais do testbench aos sinais equivalentes do design
            clk_in  => clk_in,
            reset   => reset,
            clk_out => clk_out
        );

    --define o clock de entrada (10ns)
    clk_process: process
    begin
        while true loop
            clk_in <= '0';
            wait for 5 ns;
            clk_in <= '1';
            wait for 5 ns;
        end loop;
    end process;

    --estimulo + monitoramento
    stim_process: process
    begin
        --reset inicial para garantir que o sinal count no design vai partir do '0'
        reset <= '1';
        wait for 10 ns;
        reset <= '0';

        --observa comportamento da saída
        for i in 0 to 200 loop --persiste por 201 ciclos
            wait for 5 ns; --me possibilita observar a cada borda do clock ou apenas
            			   --a borda que eu desejar.

            report "Tempo: " & time'image(now) &
                   " | clk_in=" & std_logic'image(clk_in) &
                   " | reset=" & std_logic'image(reset) &
                   " | clk_out=" & std_logic'image(clk_out);
        end loop;

        --fim da simulação
        assert false report "Fim da simulacao" severity failure;
    end process;

end architecture;